Product: Cage Ball, October 2014

Designer: Emmanuel Patoux

Support:  http://forums.obrary.com/category/designs/cage-ball

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
This is a small Cage Ball that can be used for a variety of uses like a Christmas ball attached to a Christmas tree. It is made on the Laser Cutter from 3mm MDF or acrylic.